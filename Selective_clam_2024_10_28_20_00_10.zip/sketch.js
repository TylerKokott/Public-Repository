let img;
let transImg;

function preload(){
  img = loadImage("Space1.jpg");
  transImg = loadImage("spaceman.png");
}

var greetings = "outerspace!!!";
function setup() {
  createCanvas(400, 400);
  textFont('Courier New');
  fill(0,255,0);
  noStroke();
}

function draw() {
  background(220);
  
  
  image(img,0,0);
  
  image(transImg,mouseX-100,mouseY-100);
  textSize(18);
  text(greetings,125,100);
  
}