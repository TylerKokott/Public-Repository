function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(0);
  for(var x = -20; x < width + 60; x += 60){
  clouds(x,0);
  }
  print("It's raining it's pouring the old man is snoring.");
}
function clouds(x,y){
  push();
  translate(x,y);
  noStroke();
  fill(150);
  circle(30,100,40);
  circle(45,115,40);
  circle(50,95,40);
  circle(70,110,40);
  scale(1);
  fill(0,175,255);
  triangle(26,300,34,280,45,300);
  triangle(51,175,59,155,70,175);
  triangle(61,250,69,230,80,250);
  circle(35, 300, 20);
  circle(60,175,20);
  circle(70,250,20);
  angleMode(DEGREES);
  rotate(10);
  stroke(255);
  line(60,230,80,275);
  line(70,125,80,150);
  line(95,200,105,225);
  pop();
}