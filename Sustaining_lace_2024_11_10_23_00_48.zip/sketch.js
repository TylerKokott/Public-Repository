function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(225,50,100);
  setCenter(200,200);
  
 
  polarTriangles(40,50,100);
  
  fill(255);
  ellipse(0,0,200,200);
  
  ellipse(0,0,50,50);
  fill(0);
  polarSquares(10,20,40);
}